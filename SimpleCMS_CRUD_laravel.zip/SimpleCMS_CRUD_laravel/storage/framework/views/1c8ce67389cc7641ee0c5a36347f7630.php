<h1>Home Page</h1>

<?php /**PATH D:\Documents\Laravel-project-demo\SimpleCMS_CRUD_laravel\resources\views/home.blade.php ENDPATH**/ ?>
