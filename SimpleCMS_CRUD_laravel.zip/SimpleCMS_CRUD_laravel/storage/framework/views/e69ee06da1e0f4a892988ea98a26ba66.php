<?php $__env->startSection('title','Chi tiết bài viết'); ?>
<?php $__env->startSection('main'); ?>
    <h1><?php echo e($article->title); ?></h1>
    <p><?php echo e($article->content); ?></p>
    <p><?php echo e($article->author); ?></p>
    <a href="<?php echo e(route('articles.index')); ?>">Quay lai Trang Chủ</a>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documents\Laravel-project-demo\SimpleCMS_CRUD_laravel\resources\views/articles/detail.blade.php ENDPATH**/ ?>
