<div class="card bg-success position-fixed bottom-0 " style="right: 0; left: 0">
    <div class="card-header">
        Featured
    </div>
    <div class="card-body">
        <h5 class="card-title">Special title treatment</h5>
        <p class="card-text">With supporting text below as a natural lead-in to additional content.</p>
    </div>
</div>
<?php /**PATH D:\Documents\Laravel-project-demo\SimpleCMS_CRUD\resources\views/layout/footer.blade.php ENDPATH**/ ?>