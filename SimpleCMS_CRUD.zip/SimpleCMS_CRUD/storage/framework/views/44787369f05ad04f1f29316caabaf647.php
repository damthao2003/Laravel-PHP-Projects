<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title> <?php echo $__env->yieldContent('title'); ?> </title>
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>
<header>
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</header>

<main>
    <?php echo $__env->yieldContent('main'); ?>

</main>





<link rel="stylesheet" href="<?php echo e(asset('js/bootstrap.bundle.js')); ?>">
<?php echo $__env->yieldContent('library'); ?>
</body>
</html>
<?php /**PATH D:\Documents\Laravel-project-demo\SimpleCMS_CRUD\resources\views/layout/parent.blade.php ENDPATH**/ ?>