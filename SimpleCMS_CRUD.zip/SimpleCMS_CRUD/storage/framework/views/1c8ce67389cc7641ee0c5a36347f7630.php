<h1>Home Page</h1>

<?php /**PATH D:\Documents\Laravel-project-demo\SimpleCMS_CRUD\resources\views/home.blade.php ENDPATH**/ ?>