<h1>Hello </h1>
<?php /**PATH D:\Documents\Laravel-project-demo\SimpleCMS_CRUD\resources\views/welcome.blade.php ENDPATH**/ ?>