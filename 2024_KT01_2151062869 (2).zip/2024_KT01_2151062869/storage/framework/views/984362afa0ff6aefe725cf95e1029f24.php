
<?php echo $__env->make('layout.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documents\Laravel-project-demo\2024_KT01_2151062869\resources\views/home.blade.php ENDPATH**/ ?>
