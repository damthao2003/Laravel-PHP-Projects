<?php $__env->startSection('main'); ?>




    <style>
        ::placeholder{
            color: darkgray !important;
        }
        h4{
            color: red;
        }
        label{
            font-weight: 600;
        }


    </style>

    <h4 class="text-center text-uppercase mt-2">Create Contact</h4>

    <form action="<?php echo e(route('persons.store')); ?>" method="POST" class="w-75 m-auto " style="">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label" for="name" >Name</label>
            <input type="text" class="form-control" name="name" id="name" placeholder="Enter name">
        </div>
        <div class="mb-3">
            <label class="form-label" for="email">Email</label>
            <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
        </div>
        <div class="mb-3">
            <label  class="form-label" for="phone">Phone</label>
            <input type="phone" class="form-control" name="phone" id="phone" placeholder="Enter phone">
        </div>
        <div class="mb-3">
            <label  class="form-label" for="title">Title</label>
            <input type="text" class="form-control" name="title" id="title" placeholder="Enter title">
        </div>
        <div class="mb-3">
            <label  class="form-label" for="title">Department</label>
            <select class="form-select" aria-label="Default select example" >
                <option selected class="opt1">Select department</option>
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="1"><?php echo e($depart->name); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="float-end">
            <button type="submit" class="btn btn-primary ">Submit</button>
            <a href="<?php echo e(route('persons.index')); ?>" class="btn btn-danger">Cancel</a>
        </div>
    </form>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documents\Laravel-project-demo\2024_KT01_2151062869\resources\views/persons/add.blade.php ENDPATH**/ ?>