<?php

namespace App\Http\Controllers;

use App\Models\Person;
use App\Models\Department;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PersonController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
       // $persons = Person::all();
      // $persons = Person::orderBy('id','desc')->take(10)->get(); // lay ra 10 ban ghi
       // $persons = DB::table('persons')->paginate(5);
        $persons = Person::paginate(5);
        $departments = Department::all();

        return view('persons.index', compact('persons','departments'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $departments = Department::all();
        return view('persons.add', compact('departments'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $name = $request->name;
        $email = $request->email;
        $phone = $request->phone;
        $title = $request->title;
        $department_name = $request->department_name;


        $person = new Person();
        $person->name = $name;
        $person->email = $email;
        $person->phone = $phone;
        $person->title = $title;

        $department = new Department();
       if($department->name = $department_name){
          $person->department_id = $department->id;
       }

        $person->save();

        return redirect()->route('persons.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $person = Person::find($id);
        return view('persons.detail', compact('person'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $person = Person::find($id);
        return view('persons.edit',compact('person'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //c1
//        $name = $request->name;
//        $email = $request->email;
//        $phone = $request->phone;
//        $title = $request->title;
//
//        $person = new Person();
//        $person->name = $name;
//        $person->email = $email;
//        $person->phone = $phone;
//        $person->title = $title;
//
//        $person->update($person);
//
        //c2
        $validateData = $request->validate([ // data moi muon sua
            'name' => 'required',
            'email' =>'required',
            'phone' => 'required',
            'title' => 'required'
        ]);
        $person = Person::find($id);// data trong db can sua

        $person->update($validateData);
        return redirect()->route('persons.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $person = Person::find($id);
        $person->delete();
        return redirect()->route('persons.index');
    }
}
