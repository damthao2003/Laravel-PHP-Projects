
@extends('layout.parent')
@section('main')

{{--    @push('styles')--}}
{{--        <link rel="stylesheet" href="{{asset('css/add.css')}}">--}}
{{--    @endpush--}}
    <style>
        ::placeholder{
            color: darkgray !important;
        }
        h4{
            color: red;
        }
        label{
            font-weight: 600;
        }


    </style>

    <h4 class="text-center text-uppercase mt-2">Create Contact</h4>

    <form action="{{route('persons.store')}}" method="POST" class="w-75 m-auto " style="">
        @csrf
        <div class="mb-3">
            <label class="form-label" for="name" >Name</label>
            <input type="text" class="form-control" name="name" id="name" placeholder="Enter name">
        </div>
        <div class="mb-3">
            <label class="form-label" for="email">Email</label>
            <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
        </div>
        <div class="mb-3">
            <label  class="form-label" for="phone">Phone</label>
            <input type="phone" class="form-control" name="phone" id="phone" placeholder="Enter phone">
        </div>
        <div class="mb-3">
            <label  class="form-label" for="title">Title</label>
            <input type="text" class="form-control" name="title" id="title" placeholder="Enter title">
        </div>
        <div class="mb-3">
            <label  class="form-label" for="title">Department</label>
            <select class="form-select" aria-label="Default select example" >
                <option selected >Select department</option>
                @foreach($departments as $depart)
                    <option value="1" name="department_name" id="department_name">{{$depart->name}} </option>
                @endforeach
            </select>
        </div>
        <div class="float-end">
            <button type="submit" class="btn btn-primary ">Submit</button>
            <a href="{{route('persons.index')}}" class="btn btn-danger">Cancel</a>
        </div>
    </form>

@endsection


