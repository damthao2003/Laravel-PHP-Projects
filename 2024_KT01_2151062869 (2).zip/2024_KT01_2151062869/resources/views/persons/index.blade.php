@extends('layout.parent')

@section('title','Read Contact')

{{--<?php--}}
{{--$itemPerPage = 10;--}}
{{--$currentPage = isset($_GET['page']) ? $_GET['page'] : 1;--}}
{{--//$totalPages = ceil(count($articles) / $itemPerPage);--}}
{{--?>--}}

@section('main')
    <div class="container">
        <h4 class="mt-1">Read Contact</h4>
        <hr>
        <a href="{{route('persons.create')}}" class="btn btn-success">Create Contact</a>
        <div class=" mt-3">
            <table class="table m-1">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Title</th>
                    <th scope="col">Department</th>
                    <th scope="col" colspan="2">Action</th>
                </tr>
                </thead>
                <tbody>
                @foreach($persons as $person)
                    <tr>
                        <th scope="row"> {{$person->id}}</th>
                        <td>{{$person->name}}</td>
                        <td>{{$person->email}}</td>
                        <td>{{$person->phone}}</td>
                        <td>{{$person->title}}</td>
                        @foreach($departments as $depart)
                            @if($person->department_id == $depart->id)
                                <td>{{$depart->name}}</td>
                            @endif
                        @endforeach
                        <td>
                            <a href="{{route('persons.edit', $person->id)}}" class="btn btn-primary">
                                <i class="bi bi-pencil-square"></i> </a>
                        </td>
                        <td>
{{--                            <a href="{{route('persons.destroy',$person->id)}}" class="btn btn-danger">--}}
                                <form action="{{ route('persons.destroy',$person->id) }}" method="POST">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger"><i class="bi bi-trash3-fill"></i></button>
                                </form>
{{--                            </a>--}}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>

        <div class="">
            {{$persons->onEachSide(1)->links()}}
        </div>

    </div>


@endsection


