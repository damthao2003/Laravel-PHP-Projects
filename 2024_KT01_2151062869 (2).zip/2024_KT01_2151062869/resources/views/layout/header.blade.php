<nav class="nav" style="background: #5e5ecb">
    <div class="d-flex justify-content-between" >
        <div class="mr-5" style="margin-left: 100px">
            <a class="nav-link active" aria-current="page" href="#" style="color: white">Web Title</a>
        </div>
        <div class="d-flex nav-item ml-2" style="margin-left: 800px">
            <a class="nav-link text-white"  href="#"> <i class="bi bi-house-door"></i> Home</a>
            <a class="nav-link text-white" href="#"><i class="bi bi-person-rolodex"></i> Contact</a>
        </div>
    </div>
</nav>


