<h1>jkbcks</h1>
<?php /**PATH D:\Documents\Laravel-project-demo\2024_KT01_2151062869\resources\views/home.blade.php ENDPATH**/ ?>