<nav class="nav" style="background: #5e5ecb">
    <div class="nav d-flex justify-content-between" >
        <div class="mr-5" style="margin-left: 100px">
            <a class="nav-link active" aria-current="page" href="#" style="color: white">Web Title</a>
        </div>
        <div class="d-flex nav-item ml-2" style="margin-left: 850px">
            <a class="nav-link text-white"  href="#"> <i class="bi bi-house-door"></i> Home</a>
            <a class="nav-link text-white" href="#"><i class="bi bi-person-rolodex"></i> Contact</a>
        </div>
    </div>
</nav>


<?php /**PATH D:\Documents\Laravel-project-demo\2024_KT01_2151062869\resources\views/layout/header.blade.php ENDPATH**/ ?>