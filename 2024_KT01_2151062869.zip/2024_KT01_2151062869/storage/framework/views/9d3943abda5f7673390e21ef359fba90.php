

<?php $__env->startSection('title','List Contact'); ?>;








<?php $__env->startSection('main'); ?>
    <div class="container">
        <h3 class="mt-2">Read Contact</h3>
        <hr>
        <a href="<?php echo e(route('persons.create')); ?>" class="btn btn-success">Create Contact</a>
        <div class="table">
            <table class="table mt-3">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Title</th>
                    <th scope="col">Created</th>
                    <th scope="col" colspan="2"></th>

                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"> <?php echo e($person->id); ?></th>
                        <td><?php echo e($person->name); ?></td>
                        <td><?php echo e($person->email); ?></td>
                        <td><?php echo e($person->phone); ?></td>
                        <td><?php echo e($person->title); ?></td>
                        <td>
                            <a href="<?php echo e(route('persons.edit', $person->id)); ?>" class="btn btn-primary">
                                <i class="bi bi-pencil-square"></i> </a>
                        </td>
                        <td>

                                <form action="<?php echo e(route('persons.destroy',$person->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger"><i class="bi bi-trash3-fill"></i></button>
                                </form>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>

            </table>
    </div>

    </div>

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout.parent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Documents\Laravel-project-demo\2024_KT01_2151062869\resources\views/persons/index.blade.php ENDPATH**/ ?>